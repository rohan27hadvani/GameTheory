package GameTheory.Strategies;

public class AlwaysCooperate extends Strategy {

	public AlwaysCooperate() {
		super();
	}

	/**
	 * Always cooperate; therefore, always return true
	 *
	 * @return true
	 */
	@Override
	public boolean makeMove() {
		return true;
	}

}
