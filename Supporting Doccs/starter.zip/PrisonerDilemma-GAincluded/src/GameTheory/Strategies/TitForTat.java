package GameTheory.Strategies;

public class TitForTat extends Strategy {

    /**
     * This strategy (Tit-For-Tat) copies the previous move of the opposing player.
     * This is generally known as a fairly good strategy, as it is simultaneously
     * nice, forgiving, and revengeful.
     *
     * This requires adding opponent move history after each battle
     */

    public TitForTat() {
        super();
    }

    @Override
    public boolean makeMove() {
        if (opponentMoveHistory.size() == 0) {
            return true;
        }
        return opponentMoveHistory.get(opponentMoveHistory.size() - 1);
    }

    @Override
    public String getStrategyName() {
        return "TitForTat";
    }
}
