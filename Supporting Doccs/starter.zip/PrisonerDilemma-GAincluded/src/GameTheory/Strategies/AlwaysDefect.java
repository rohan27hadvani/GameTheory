package GameTheory.Strategies;

public class AlwaysDefect extends Strategy {

	public AlwaysDefect() {
		super();
	}

	/**
	 * Always defect; therefore, always return false
	 *
	 * @return false
	 */
	@Override
	public boolean makeMove() {
		return false;
	}

}
